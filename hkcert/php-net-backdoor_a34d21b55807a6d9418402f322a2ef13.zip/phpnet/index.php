<?php 
  if(isset($_GET['url']) && preg_match('@^https://www\.php\.net/@',$_GET['url'])){
    $tmp = tmpfile();
    fwrite($tmp, file_get_contents($_GET['url']));
    @include_once(stream_get_meta_data($tmp)['uri']);
    fclose($tmp);
  }else{
    show_source(__FILE__);
  }
?>