from pwn import *

p = process("./sus")
libc = ELF("/lib/x86_64-linux-gnu/libc.so.6")
# r = remote("")
# libc = ELF("./libc.so.6")

pause()

payload = b"aaaabaaacaaadaaaeaaafaaagaaahaaaiaaajaaakaaalaaamaaanaaaoaaapaaaqaaaraaasaaataaauaaavaaawaaaxaaayaaa"
r.sendline(payload)

