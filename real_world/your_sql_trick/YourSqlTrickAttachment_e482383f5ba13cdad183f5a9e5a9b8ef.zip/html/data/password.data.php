<?php
$str_password='{"1":"1704355783"}';