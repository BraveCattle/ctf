<?php  if(!defined('DEDEINC')) exit('DedeCMS Error: Request Error!');
/**
 * 仅用于测试
 *
 * @version        $Id: test.helper.php 5 15:01 2010年7月5日 $
 * @package        DedeCMS.Helpers
 * @founder        IT柏拉图, https://weibo.com/itprato
 * @author         DedeCMS团队
 * @copyright      Copyright (c) 2007 - 2021, 上海卓卓网络科技有限公司 (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */

//邮箱格式检查
if ( ! function_exists('HelloDede'))
{
    function HelloDede()
    {
        echo "Hello! Dede...";
    }
}